#include "Reloj.h"

Reloj::Reloj()
{
    //ctor
}

Reloj::~Reloj()
{
    //dtor
}
